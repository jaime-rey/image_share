(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// image_share.js                                                      //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
if (Meteor.isClient) {                                                 // 1
    var img_data = [{                                                  // 2
        img_src: "cav.jpg",                                            // 4
        img_alt: "lannisters always paid their debts"                  // 5
    }, {                                                               //
        img_src: "ali.jpg",                                            // 8
        img_alt: "alita is hot"                                        // 9
    }, {                                                               //
        img_src: "crim.jpg",                                           // 12
        img_alt: "crimson king"                                        // 13
    }, {                                                               //
        img_src: "dwarf.jpg",                                          // 16
        img_alt: "bleroooooooooooo"                                    // 17
    }, {                                                               //
        img_src: "goat.jpg",                                           // 20
        img_alt: "puta cabra"                                          // 21
    }, {                                                               //
        img_src: "scp.jpg",                                            // 24
        img_alt: "don�t blink"                                         // 25
    }, {                                                               //
        img_src: "smt.jpg",                                            // 28
        img_alt: "yellow king"                                         // 29
    }];                                                                //
    Template.images.helpers({ images: img_data });                     // 32
}                                                                      //
                                                                       //
if (Meteor.isServer) {}                                                // 35
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=image_share.js.map
